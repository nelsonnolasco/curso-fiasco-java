package NivelIntermediario;

public class Ninja {
    String nome;
    String aldeia;
    int idade;

}
