package NivelIntermediario;

public interface HyugaUzumaki {

    void AtivarOKarma();

    void AtivarJougan();

}
