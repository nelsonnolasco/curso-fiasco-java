package NivelIntermediario;

public class Boruto extends Uzumaki implements HyugaUzumaki {

    public void AtivarOKarma() {
        System.out.println("O Karma foi ativado! Eu sou um Hyuga Uzumaki");
    }

    public void AtivarJougan() {
        System.out.println("Jougan foi ativado com sucesso! Eu sou um Hyuga Uzumaki");
    }

}
