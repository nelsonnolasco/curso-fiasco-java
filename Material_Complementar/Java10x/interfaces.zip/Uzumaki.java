package NivelIntermediario;

public class Uzumaki extends Ninja {

    public void ModoSabioAtivado() {
        System.out.println("Meu é " + nome + ". E eu ativei o modo Sabio"  );
    }

}
