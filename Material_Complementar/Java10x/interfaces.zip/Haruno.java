package NivelIntermediario;

import java.security.PublicKey;

public class Haruno extends Ninja {

    public void AtivarCura() {
        System.out.println("Eu sou " + nome + ". E eu ativei minha cura fora do comum ");
    }
}
