package NivelIntermediario;

public class Uchiha extends Ninja {

    //Sharingan ativado, metodo publico
    public void SharinganAtivado() {
        System.out.println("Meu nome é " + nome + ". O Sharingan Ativou, eu sou um Uchiha!");
    }
}
