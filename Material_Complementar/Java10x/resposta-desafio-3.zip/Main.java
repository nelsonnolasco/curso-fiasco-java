package NivelIntermediario;

public class Main {
    public static void main(String[] args) {

        // Inicializar o obj
        Uchiha sasuke = new Uchiha();
        sasuke.nome = "Sasuke Uchiha";
        sasuke.idade = 18;
        sasuke.missao = "Recuperar o amuleto";
        sasuke.nivelDeDificuldade = "Alta";
        sasuke.statusDaMissao = "Em andamento";
        sasuke.mostrarInformacoes();


    }
}


